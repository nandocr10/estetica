// config.js
module.exports = {
    apiUrl: 'https://api.exemplo.com/validarCpf', // URL fictícia
    authToken: 'seu-token-aqui' // Substitua pelo token correto
};

