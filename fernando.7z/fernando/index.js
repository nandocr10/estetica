// index.js
const fs = require('fs');
const readline = require('readline');
const { validarCpf } = require('./apiService');

async function processarArquivo(caminhoArquivo) {
    if (!fs.existsSync(caminhoArquivo)) {
        console.error(`Erro: O arquivo '${caminhoArquivo}' não foi encontrado.`);
        console.log(`Erro: O arquivo '${caminhoArquivo}' não foi encontrado.`);
        return;
    }
    
    const stream = fs.createReadStream(caminhoArquivo);
    const rl = readline.createInterface({ input: stream });
    
    for await (const linha of rl) {
        const cpf = linha.trim();
        if (cpf) {
            const resultado = await validarCpf(cpf);
            console.log(`CPF: ${cpf}, Resultado:`, resultado);
        }
    }
}

const arquivo = 'cpfs.txt'; // Nome do arquivo de entrada
processarArquivo(arquivo).catch(console.error);