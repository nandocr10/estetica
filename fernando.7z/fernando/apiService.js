// apiService.js
const axios = require('axios');
const { apiUrl, authToken } = require('./config');

async function validarCpf(cpf) {
    try {
        const response = await axios.post(apiUrl, { cpf }, {
            headers: { Authorization: `Bearer ${authToken}` }
        });
        return response.data;
    } catch (error) {
        console.error(`Erro ao validar CPF ${cpf}:`, error.response?.data || error.message);
        return null;
    }
}

module.exports = { validarCpf };
